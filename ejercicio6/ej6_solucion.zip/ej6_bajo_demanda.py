from threading import active_count
from time import sleep
import os
from ej6_herramientas import color_print
from ej6_vigilante import Vigilante
from ej6_chiste import Chistosa
from ej6_dato import Sabia
from ej6_termometro import Termometro
from ej6_esperadora import Esperadora


if __name__ == "__main__":
    archivo_vigilado = "temp.txt"
    vigilante = Vigilante(archivo_vigilado)
    vigilante.start()

    nr_max_hebras = 3
    tipos_de_ordenes = {"chiste": Chistosa,
                        "dato": Sabia,
                        "temp": Termometro,
                        "espera": Esperadora}

    orden_arg_str = input("\n¿Qué quieres hacer? ")
    while orden_arg_str != "salir":
        if active_count() > nr_max_hebras:
            color_print("Hay demasiadas hebras vivas. Inténtalo más tarde.", "rojo")
        else:
            orden_arg_lst = orden_arg_str.split(" ", 1)
            if len(orden_arg_lst) == 1:
                tipo_orden = orden_arg_lst[0]
                orden = tipos_de_ordenes[tipo_orden]  # falla si `tipo_orden` no se conoce
                hebra = orden()
            else:
                tipo_orden, arg = orden_arg_lst
                orden = tipos_de_ordenes[tipo_orden]  # falla si `tipo_orden` no se conoce
                hebra = orden(arg)
            # Python permite hacer eso: por ejemplo, si tipo es `espera`,
            # eso equivale a `hebra = Esperadora(argumento)`.
            # Siempre paso el argumento como un string, incluso la duración de la espera.
            hebra.start()
        orden_arg_str = input("\n¿Qué quieres hacer? ")

    if os.path.exists(archivo_vigilado):
        os.remove(archivo_vigilado)
    # En mi diseño, el vigilante para cuando el archivo vigilado ya no existe.
    # Por eso en este punto borro el archivo si aún existe.
    while active_count() > 1:
        color_print(f"Hebras hijas aún vivas: {active_count()-1}. A ver si acaban...", "rojo")
        sleep(3)
    color_print(f"Hemos acabado.", "verde")
