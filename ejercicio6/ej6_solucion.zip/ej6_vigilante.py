from threading import Thread
from ej6_herramientas import vigila


class Vigilante(Thread):
    def __init__(self, nombre: str) -> None:
        super().__init__()
        self.nombre = nombre

    def run(self):
        with open(self.nombre, 'w'):  # crea el archivo vacío si no existe
            pass
        # Imprime el contenido del archivo vigilado cada vez que se modifica.
        # Para cuando el archivo ya no existe.
        vigila(self.nombre)
