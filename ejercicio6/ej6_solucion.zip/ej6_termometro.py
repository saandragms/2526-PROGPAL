from threading import Thread
from ej6_herramientas import color_print, pide_temperatura


class Termometro(Thread):
    def __init__(self, ciudad: str) -> None:
        super().__init__()
        self.ciudad = ciudad

    def run(self):
        t = pide_temperatura(self.ciudad)
        color_print(f"temperatura en {self.ciudad}: {t}", "azul")
