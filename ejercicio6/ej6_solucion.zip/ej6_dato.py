from threading import Thread
from ej6_herramientas import color_print, pide_dato_random


class Sabia(Thread):
    def __init__(self) -> None:
        super().__init__()

    def run(self):
        dato = pide_dato_random()
        color_print(f"Dato: {dato}", "morado")
