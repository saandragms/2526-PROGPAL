from threading import Thread
from ej6_herramientas import color_print, pide_chiste


class Chistosa(Thread):
    def __init__(self) -> None:
        super().__init__()

    def run(self):
        chiste = pide_chiste()
        color_print(f"Chiste: {chiste}", "morado")
