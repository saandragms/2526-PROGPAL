from threading import Thread
from ej6_herramientas import color_print, espera_online


class Esperadora(Thread):
    def __init__(self, duracion_str: str) -> None:
        super().__init__()
        self.duracion = int(duracion_str)  # fallará si no se puede convertir a int

    def run(self):
        espera_online(self.duracion)
        color_print("Espera completada.", "azul")
